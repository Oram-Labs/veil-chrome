/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_localveil_free: (a: number, b: number) => void;
export const localveil_activity: (a: number) => [number, number];
export const localveil_clear_vault: (a: number) => void;
export const localveil_configure: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const localveil_handle: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
export const localveil_load_activity: (a: number, b: number, c: number) => [number, number];
export const localveil_load_vault: (a: number, b: number, c: number) => [number, number];
export const localveil_new: (a: number, b: number, c: number, d: number) => [number, number, number];
export const localveil_set_now: (a: number, b: number) => void;
export const localveil_set_running: (a: number, b: number) => void;
export const localveil_take_vault_changes: (a: number) => [number, number];
export const localveil_test_rules: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
export const localveil_vault_info: (a: number) => [number, number];
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
