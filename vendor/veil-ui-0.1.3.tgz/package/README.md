# veil-ui

The screens of the Veil app (Rules, Behavior, Playground, Vault, Activity, General) as a Svelte 5 package, shared by the app and the browser extension. A host gives the screens a `Backend` and calls `start(backend)`; capabilities in the Backend hide what a host can't do.

```
pnpm check && pnpm test && pnpm build && npm pack
```
